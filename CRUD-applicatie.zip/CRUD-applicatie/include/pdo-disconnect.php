<?php
if(isset($dbh)) {
    $dbh = null;
}
?>