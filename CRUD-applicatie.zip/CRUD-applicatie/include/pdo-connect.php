<?php

try {
    $hostname = "(local)\SQLEXPRESS";
    $dbname = "Euratex";
    $username = $_SESSION['gebruikersnaam'];
    $password = $_SESSION['wachtwoord'];
    $dbh = new PDO("sqlsrv:Server=$hostname;Database=$dbname", "$username", "$password");
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo $e->getMessage();
    echo "Er kon geen verbinding met de database gemaakt worden.";
    exit;
}

?>
