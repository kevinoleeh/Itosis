
<footer class="footer">
    <div class="container">
        <p class="text-muted">© Euratex 2017 Alle rechten voorbehouden</p>
    </div>
</footer>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<script src="js/table.js"></script>
<?php include_once('include/pdo-disconnect.php') ?>
</body>
</html>
